create_makefile("-test-/fatal/rb_fatal")
