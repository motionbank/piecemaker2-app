
void ruby_Init_Continuation_body(void);

void
Init_continuation(void)
{
    ruby_Init_Continuation_body();
}
